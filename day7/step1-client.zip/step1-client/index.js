const express = require("express");

const app = express();
app.use(express.static(__dirname+"/public"));

// Web Server
//---------------------------
app.listen(4040,"localhost",function(error){
    if(error){ console.log("Error", error )}
    else{ console.log( "web server is now live on localhost:4040" )}
});