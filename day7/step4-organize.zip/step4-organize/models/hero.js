const mongoose = require("mongoose");

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;

let Hero = mongoose.model("Hero",new Schema({
    id :  ObjectId,
    title :  String,
    firstname :  String,
    lastname :  String,
    email :  String,
    city :  String
}));

module.exports = Hero;