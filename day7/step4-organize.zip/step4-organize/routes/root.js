const express = require("express");
const Hero = require("../models/hero");

const routes = express.Router();

routes.get("/",(req,res)=>{
    res.render('index.pug');
})
routes.post("/data",(req,res)=>{
     let hero = new Hero(req.body);
     hero.save()
     .then(dbres => res.status(200).send({message : dbres.title+ " was added"}))
     .catch(dberr => res.status(500).send({"Error" : dberr}))
})
// READ
routes.get("/data",(req,res)=>{
    Hero.find()
    .then(dbres => res.send(dbres))
    .catch(error => console.log(error))    
})
// UPDATE
routes.get("/update/:hid",(req, res)=>{
    Hero.findById(req.params.hid)
    .then(dbres => res.status(200).send(dbres))
    .catch(dberr => console.log(dberr))
})
routes.post("/update/:hid",(req, res)=>{
    Hero.findByIdAndUpdate(req.params.hid,{ 
        title :  req.body.title,
        firstname :  req.body.firstname,
        lastname :  req.body.lastname,
        email :  req.body.email,
        city :  req.body.city 
        }).then(dbres => {
            console.log(dbres);
            res.send({message : "hero updated"})
        }).catch(dberr => console.log(dberr))
})
// DELETE
routes.delete("/delete/:hid",(req,res)=>{
    Hero.findByIdAndDelete(req.params.hid)
    .then(dbres => {
        console.log(dbres);
        res.status(200).send({ message : "hero deleted" })
    })
    .catch(error => {
        console.log(error)
    })
});


module.exports = routes;