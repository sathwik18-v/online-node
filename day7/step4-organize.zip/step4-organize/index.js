const express = require("express");
const mongoose = require("mongoose");
const config = require("./config.json");
const morgan = require('morgan');
const root = require("./routes/root");
let port = process.env.PORT || config.port;

const app = express();
// Middlewares
//---------------------------
// app.use(express.static(__dirname+"/public",{index : "default.html"}));
app.use(express.static(__dirname));
app.use(morgan('tiny'));
app.use(express.json());
app.use(root);
// DB Connection
//---------------------------
let dbsrting = "mongodb+srv://{{uname}}:{{upass}}@cluster0.{{userstring}}.mongodb.net/{{dbname}}?retryWrites=true&w=majority&appName=Cluster0"
let url = dbsrting.replace("{{uname}}",config.dbusername).replace("{{upass}}",config.dbpassword).replace("{{userstring}}",config.userstring).replace("{{dbname}}",config.dbname);
mongoose.connect(url)
.then((res)=> console.log("DB Connected") )
.catch((err)=> console.log("Error ", err) )

// Web Server
//---------------------------
app.listen(port,config.host,function(error){
    if(error){ console.log("Error", error )}
    else{ console.log( `web server is now live on ${config.host}:${port}` )}
});