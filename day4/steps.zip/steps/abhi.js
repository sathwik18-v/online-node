const express = require("express");
const path = require("node:path");

let app = express();
let config = require("./config.json");

let port = process.env.PORT || config.port;
app.use('/images/antman.jpg', express.static(path.join(__dirname, 'images','batman.jpg')));
app.use(express.static(__dirname));

app.get("/", (req,res)=>{
res.sendFile(__dirname+"/index.html");
});

app.listen(port,config.host,(error) => {
    if(error){
        console.log("Error", error)
    }else{
        console.log(process.env.PORT);
        // console.log(location.address().port);
        console.log(`express is serving on ${config.host}:${port}`);
    }
});
