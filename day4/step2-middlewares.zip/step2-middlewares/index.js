const express = require("express");
const app = express();

// MIDDLEWARE
//-----------------------------------
// global middlewares
app.use(function(req, res, next){
    console.log("first middle ware");
    console.log(req.url);
    next();
})
app.use(function(req, res, next){
    console.log("second middle ware");
    next();
})
app.use("/vijay",function(req, res, next){
    console.log("vijay route was activated");
    next();
})
//-----------------------------------
function anythinghandler(req, res, next){
    console.log("we have a request for anything 1");
    next();
}
function oneMoreAnythingHandler(req, res, next){
    console.log("we have a request for anything 2");
    next();
}
//-----------------------------------
/* default route */
app.get("/",(req, res) => {
    res.send("welcome to your life");
})
/* named route */
app.get("/anything",anythinghandler,oneMoreAnythingHandler,(req, res) => {
    res.send("welcome to your life, there's no turning back");
})
/* wildcard route */
app.get("**",(req, res) => {
    res.send("even while you sleep... we will find you acting on your best behaviour");
})

app.listen(6060,"localhost",error => {
    if(error){
        console.log("Error ", error)
    }else{
        console.log("Server is now live on localhost:6060")
    }
})