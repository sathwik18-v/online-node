const express = require("express");
const app = express();

app.get("/",function(req, res){
    res.render("home.pug");
})
app.get("/login",function(req, res){
    res.render("login.pug");
})
app.get("/register",function(req, res){
    res.render("register.pug");
})
app.get("/profile",function(req, res){
    res.render("profile.pug");
})
app.get("/logout",function(req, res){
    // res.render("logout.pug");
})

app.listen(6060,"localhost",function(error){
    if(error){console.log("Error", error)}
    else{ console.log("Server is now live on localhost:6060")}
});