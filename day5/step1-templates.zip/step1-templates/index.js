const express = require("express");
const app = express();
let compname = "Intellipaat";
/* default route */
app.get("/", (req, res) => {
    res.render("home.ejs");
})
/* named route */
app.get("/about", (req, res) => {
    res.render("about.ejs");
})
app.get("/about/:message", (req, res) => {
    res.render("past.ejs",{ message : req.params.message, compname });
})
/* named route */
app.get("/contact", (req, res) => {
    res.render("contact.ejs");
})
/* catch all route */
app.get("**", (req, res) => {
    res.render("notfound.ejs");
})

app.listen(1010,"localhost",error => {
    if(error){
        console.log("Error ", error)
    }else{
        console.log("Server is now live on localhost:1010")
    }
})