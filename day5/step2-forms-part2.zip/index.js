const express = require("express");
const app = express();

// default template engine
app.set('view engine', 'ejs');
// change default template folder location
app.set("views",__dirname+"/templates");
// use urlencoded data
app.use(express.urlencoded({ extended : true }));
// required for ejs
app.use(express.static(__dirname+"/templates"));

let justiceleague = [];

app.get("/",(req, res)=>{
    res.render("home", { justiceleague })
})
app.post("/",(req, res)=>{
    // res.render("home");
    // console.log("i got a post request");
    // console.log(req.body.username);
    justiceleague.push(req.body.username);
    // console.log(justiceleague);
    // res.send("your request is now under process");
    res.redirect("/");
})

app.listen(2020,"localhost",error => {
    if(error){ console.log("Error ", error)}
    else{ console.log("Server is now live on localhost:2020")}
})