const express = require("express");

let app = express();

app.get("/", function(req, res){
    /* 
    res.writeHead(200,{ "Content-Type" : "text/plain" });
    res.write("welcome to your life");
    res.end();
    */
   res.json({"message" : "welcome to your life"});
});


app.listen(2020,"localhost",(error)=>{
    if(error){ console.log("Error", error) }
    else{ console.log("server is now live on localhost:2020") }
});
