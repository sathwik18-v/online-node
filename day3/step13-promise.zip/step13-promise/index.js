/* let favnum = [33,7,55,4,4,47,29,55,5,4,25,7,89,78,7,37,8,55,3,67,69,28];
let promise = new Promise(function(resolve, reject){
    setTimeout(function(){
        if(true){
            resolve(favnum);
        }else{
            reject("promise was reject");
        }
    },2000);
});  */
//==================================================
/*
promise
.then(function(res){
    console.log("Resolve",res )
})
.catch(function(err){
    console.log("Reject",err )
})
.finally(function(){
    console.log("Promise is now settled");
})
*/

/*
    promise.then(
    function(res){
        console.log("Resolve",res )
    },
    function(err){
        console.log("Reject",err )
    }) 
 */
/* 
    promise
    .then(function(res){
        console.log("Resolve",res );
        return res.filter(function(val){
            return val > 50;
        })
    })
    .then(function(res){
        console.log("Resolve",res );
        return res.reduce(function(initval,val){
            return initval + val;
        });
    })
    .then(function(res){
        console.log("Resolve",res )
    })
    .catch(function(err){
        console.log("Reject",err )
    })
    .finally(function(){
        console.log("Promise is now settled");
    })

*/


let promise1 = function(){
    return new Promise(function(resolve, reject){
        setTimeout(function(){
            if(true){
                resolve("promise1 was resolved");
            }else{
                reject("promise1 was reject");
            }
        },3000);
    }); 
};
let promise2 = function(){
    return new Promise(function(resolve, reject){
        setTimeout(function(){
            if(true){
                resolve("promise2 was resolved");
            }else{
                reject("promise2 was reject");
            }
        },2000);
    }); 
};
let promise3 = function(){
    return new Promise(function(resolve, reject){
        setTimeout(function(){
            if(false){
                resolve("promise3 was resolved");
            }else{
                reject("promise3 was reject");
            }
        },500);
    }); 
};

/* 
promise1()
.then((res)=>console.log(res))
.catch((err)=>console.log(err))
.finally(()=>console.log("promises settled"));

promise2()
.then((res)=>console.log(res))
.catch((err)=>console.log(err))
.finally(()=>console.log("promises settled"));

promise3()
.then((res)=>console.log(res))
.catch((err)=>console.log(err))
.finally(()=>console.log("promises settled")); 
*/

/*
Promise.all([promise1(),promise2(),promise3()])
.then(res => console.log(res))
.catch(err => console.log(err));
*/

/* 
Promise.any([promise1(),promise2(),promise3()])
.then(res => console.log(res))
.catch(err => console.log(err));
*/

/* 
Promise.race([promise1(),promise2(),promise3()])
.then(res => console.log(res))
.catch(err => console.log(err)); 
*/

Promise.allSettled([promise1(),promise2(),promise3()])
.then(res => console.log(res))
.catch(err => console.log(err)); 