let ph = require("pageharvest");

// ph.fetchThatUrl("http://ibm.com","ibm.html");
// ph.fetchThatUrl("http://whiskyrasam.com","wr.html");