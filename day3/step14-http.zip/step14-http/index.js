let http = require("node:http");
let fs = require("node:fs");


let server = http.createServer((request, response)=>{
    // response.writeHead(200,{ Author : "vijay" })
    // response.writeHead(200,{ "Content-Type" : "text/html" });
    // response.write(fs.readFileSync("index.html","utf-8"));
    // console.log(request.url);
    // response.end();
    response.writeHead(200,{ "Content-Type" : "text/html" });
        if(request.url === "/favicon.ico"){
            response.write("")
        }else if(request.url === "/" ){
            response.write(fs.readFileSync("index.html","utf-8"))
        }else if(request.url === "/index.html" ){
            response.write(fs.readFileSync("index.html","utf-8"))
        }else if(request.url === "/about.html"){
            response.write(fs.readFileSync("about.html","utf-8"))
        }else if(request.url === "/contact.html"){
            response.write(fs.readFileSync("contact.html","utf-8"))
        }else{
            response.write(fs.readFileSync("notfound.html","utf-8"))
        }
    response.end();
});

server.listen(1010,"localhost",error => {
    if(error){console.log("Error ", error)}
    else{ console.log("webserver is now live on localhost:1010")}
})
